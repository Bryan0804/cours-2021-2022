CREATE TABLE personne
(
	id_personne INTEGER PRIMARY KEY,
	nom VARCHAR,
	prenom VARCHAR
) ;
