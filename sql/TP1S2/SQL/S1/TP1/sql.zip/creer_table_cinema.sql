CREATE TABLE cinema
(
	id_cinema INTEGER PRIMARY KEY,
	nom VARCHAR,
	adresse VARCHAR	
) ;
